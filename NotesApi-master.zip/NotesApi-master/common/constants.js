exports.fileTypes = {FOLDERS: 'Folders', NOTES: 'Notes', USERS: 'Users'}
